package amazonproducts;
public class example{
	public void main(String[] args) {
		String[] temp[1]= {"AMINE"};
	}
}