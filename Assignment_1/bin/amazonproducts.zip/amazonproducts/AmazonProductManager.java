package amazonproducts;
import java.util.InputMismatchException;
import java.util.Scanner;

public class AmazonProductManager {
    private Scanner input = new Scanner(System.in);
    private static AmazonProductList productList = new AmazonProductList(); 
    private static final int EXIT_OPTION = 0;
    private static final int LOAD_LIST = 1;
    private static final int SHOW_LIST = 2;
    private static final int ADD_PRODUCT = 3;
    private static final int EDIT_PRODUCT = 4;
    private static final int DELETE_PRODUCT = 5;
    private static final int SAVE_LIST = 6;
    private static final int SEARCH_LIST = 7;


    public static void showMenu() {
        System.out.println("================================");
        System.out.println("|| Menu - Amazon Products: A1 ||");
        System.out.println("================================");
        System.out.println("0. Exit");
        System.out.println("1. Load product list");
        System.out.println("2. Show product list");
        System.out.println("3. Add product");
        System.out.println("4. Edit a product");
        System.out.println("5. Delete a product");
        System.out.println("6. Save product list");
        System.out.println("7. Search in the list");
        System.out.println("Choose an option:");
    }


    public void manageProductList() throws AmazonProductException {
        int userInput = -1;

        while (userInput != EXIT_OPTION) {
            showMenu();
            try {
                userInput = input.nextInt();
                switch (userInput) {
                    case EXIT_OPTION:
                        exit();
                        break;
                    case LOAD_LIST:
                        createProductList();
                        break;
                    case SHOW_LIST:
                        displayProductList();
                        break;
                    case ADD_PRODUCT:
                        addProduct();
                        break;
                    case EDIT_PRODUCT:
                        editProduct();
                        break;
                    case DELETE_PRODUCT:
                        deleteProduct();
                        break;
                    case SAVE_LIST:
                        saveProductList();
                        break;
                    case SEARCH_LIST:
                        search();
                        break;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid option.");
                input.next(); 
            }
        }
    }

        public static void exit() {
        	System.out.println("Exiting...");
    }


    public static void createProductList() {
    	//productList.createList();
        System.out.println("Loading product list...");
        
    }


    public static void displayProductList() {
    	productList.printList();
        System.out.println("Displaying product list...");
    }


    public static void addProduct() throws AmazonProductException {
    	productList.add(null);
        System.out.println("Adding a product...");
    }


    public static void editProduct() {
    	//productList.edit();
        System.out.println("Editing a product...");
    }

        public static void deleteProduct() {
        	//productList.delete();
        	System.out.println("Deleting a product...");
    }

      public static void saveProductList() {
    	  //productList.saveList();
        System.out.println("Saving the product list...");
    }

    public static void search() {
    	//productList.search();
        System.out.println("Searching in the product list...");
    }

    public static void main(String[] args) throws AmazonProductException {
        AmazonProductManager manager = new AmazonProductManager();
        manager.manageProductList();
    }
}
