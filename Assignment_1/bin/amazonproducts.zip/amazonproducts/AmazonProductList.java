package amazonproducts;
import java.util.Scanner;
import java.io.*;
import java.util.ArrayList;
public class AmazonProductList extends AmazonProductUtil{
	
	Scanner input= new Scanner(System.in);
    private static final int NUMCOLS = 10;
    private String[] title;
    private ArrayList<AmazonProduct> bestsellers = new ArrayList<>();
    
	/*public String[] lineReader(String string)	{
		String[] str = new String[NUMCOLS];
		int index = 0;
		final char chComma = ',';
		final char chQuotes = '"';
		int start = 0;
		int end = string.indexOf(chComma);
		String value;
		while (start<end) {
			if (string.charAt(start)==chQuotes) {
				start++;
				end = string.indexOf(chQuotes, start+1); 
			}
			value = string.substring(start, end);
			value = value.trim();
			str[index++] = value;
			///System.out.print(value+" ");
			if (string.charAt(end)==chQuotes)
				start = end+2;
			else
				start = end+1;
			end = string.indexOf(chComma, start+1);
		}
		if (start < string.length()) {
			value = string.substring(start);
			str[index++] = value;	
		}
		return str;
	*/

    public void createList(String csvName) throws AmazonProductException{
    	try (BufferedReader br=new BufferedReader(new FileReader(csvName))){
    		String line=br.readLine();
    		title=line.split(",");
    		//can we try index < 10 ?
    		// can we use split or we should stick to linereader?
    		while((line=br.readLine()) != null) {
    			String[]temp=lineReader(line);
    			if(temp.length==NUMCOLS) {
    				AmazonProduct product =new AmazonProduct(temp);
    				bestsellers.add(product);
    			}
    		}

    	}catch(FileNotFoundException e) {
    		throw new AmazonProductException("Error file not found");
    		
    	}catch(IOException ae) {
    		throw new AmazonProductException("Erro in reading the file");
    	}    
    }

    public void saveList() throws AmazonProductException{
        // Logic to save the list
    }

    public void printList(){
        for (AmazonProduct product : bestsellers) {
            System.out.println(product);
        }
    }

    public void edit(int pos,AmazonProduct product) throws AmazonProductException{
    	if( pos < 0 || pos > bestsellers.size()) {
    		throw new AmazonProductException("Invalid position");
    	}
    	bestsellers.set(pos, product);
    }

    public void add(AmazonProduct product) throws AmazonProductException{
        bestsellers.add(product);
    }
    public void delete(int pos) throws AmazonProductException{
    	if( pos < 0 || pos > bestsellers.size()) {
    		throw new AmazonProductException("Invalid position");
    	}
    	bestsellers.remove(pos);
    }
    public AmazonProduct findProductByIndex(int pos) throws AmazonProductException{
    	if( pos < 0 || pos > bestsellers.size()) {
    		throw new AmazonProductException("Invalid position");
    	}
    	return bestsellers.get(pos);
    }
    public void search(String data) {
    	
    }
}
